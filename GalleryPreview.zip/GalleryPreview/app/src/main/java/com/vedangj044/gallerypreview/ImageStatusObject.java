package com.vedangj044.gallerypreview;

public class ImageStatusObject {

    private String thumbnailURL, ImageURL;
    private Boolean isVideo;

    public ImageStatusObject(String thumbnailURL, String imageURL, Boolean isVideo) {
        this.thumbnailURL = thumbnailURL;
        ImageURL = imageURL;
        this.isVideo = isVideo;
    }

    public String getThumbnailURL() {
        return thumbnailURL;
    }

    public void setThumbnailURL(String thumbnailURL) {
        this.thumbnailURL = thumbnailURL;
    }

    public String getImageURL() {
        return ImageURL;
    }

    public void setImageURL(String imageURL) {
        ImageURL = imageURL;
    }

    public Boolean getVideo() {
        return isVideo;
    }

    public void setVideo(Boolean video) {
        isVideo = video;
    }
}
