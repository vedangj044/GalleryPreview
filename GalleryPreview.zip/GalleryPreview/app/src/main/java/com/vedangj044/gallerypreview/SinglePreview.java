package com.vedangj044.gallerypreview;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.util.Size;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;


import com.bumptech.glide.Glide;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.theartofdev.edmodo.cropper.CropImage;
import com.vedangj044.gallerypreview.ImageStatusObject;
import com.vedangj044.gallerypreview.MediaPreview;
import com.vedangj044.gallerypreview.R;
import com.vedangj044.gallerypreview.VideoConverter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.xmlpull.v1.XmlPullParser;


public class SinglePreview extends AppCompatActivity {

    private static int MAX_DURATION  = 30000;

    private FloatingActionButton sendButton;

    private RelativeLayout parentLayout;
    private ImageButton CropRotation;

    private ProgressBar progressBar;

    // Array maintains the list of path of the images/videos which is received from intent
    private List<String> arg;

    // horizontal layout at the bottom when multi-selected
    private LinearLayout lp;

    private ImageView ImageStatus;
    private VideoView VideoStatus;

    private ImageButton deleteIcon;

    private int currentImage = -1;

    // List contains mediaPreview objects
    private List<MediaPreview> mediaPreviewsList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_preview);

        // Relative Layout
        parentLayout = findViewById(R.id.parent_layout);

        // Linear layout from the bottom of the screen
        lp  = findViewById(R.id.image_selection_list);

        // ImageButton
        CropRotation = findViewById(R.id.rotation_button);
        deleteIcon = findViewById(R.id.delete_icon);

        // Status preview
        ImageStatus = findViewById(R.id.image_status);
        VideoStatus = findViewById(R.id.video_status);

        mediaPreviewsList = new ArrayList<>();

        // On click listener to change image in view when multiple entries
        View.OnClickListener listener = v -> {
            currentImage = v.getId();
            MediaPreview m1 = getIdOfMedia(currentImage);

            if(m1.isVideo()){
                addVideo(m1);
            }
            else{
                addImage(m1);
            }

        };

        // Intent is received from GalleyViewFragment
        arg = getIntent().getStringArrayListExtra("selectedPath");

        // MediaPreviewList is populated and the index is assigned as ID to each
        for(String path: arg){
            mediaPreviewsList.add(new MediaPreview(arg.indexOf(path), path));
        }

        // When there are more than one entries we need to populate the bottom horizontal scroll layout
        if(mediaPreviewsList.size() > 1) {
            for (MediaPreview s1 : mediaPreviewsList) {
                ImageView img = new ImageView(this);

                int dimensionInDp = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, getResources().getDisplayMetrics());
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dimensionInDp, LinearLayout.LayoutParams.MATCH_PARENT);
                params.setMargins(10, 10, 10, 10);

                img.setLayoutParams(params);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);

                // ID is assigned equal to ID of mediaPreview
                img.setId(s1.getId());

                img.setOnClickListener(listener);

                Glide.with(this).load(s1.getPath()).into(img);
                lp.addView(img);

                MediaPreview m1 = getIdOfMedia(0);

                moveNext();
            }
        }
        else{

            // otherwise when only one entry is present it is displayed
            currentImage = 0;
            MediaPreview m1 = mediaPreviewsList.get(0);
            if (m1.isVideo()) {
                addVideo(m1);
            } else {
                addImage(m1);
            }
        }


        // Image cropping activity
        // Reference https://github.com/ArthurHub/Android-Image-Cropper
        CropRotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // View is updated
                MediaPreview m1 = getIdOfMedia(currentImage);
                if(!m1.isVideo()){
                    CropImage.activity(Uri.fromFile(new File(m1.getPath()))).start(SinglePreview.this);
                }
            }
        });

        // Removes the image/video from view
        deleteIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentImage != -1){
                    ImageStatus.setVisibility(View.GONE);
                    VideoStatus.setVisibility(View.GONE);
                    lp.removeView(lp.findViewById(currentImage));

                    // when an status is discarded it is deleted from mediaPreviewList as well
                    mediaPreviewsList.remove(getIdOfMedia(currentImage));
                }
                if(mediaPreviewsList.size() == 0){
                    finish();
                }
                else{
                    moveNext();
                }
            }
        });


        sendButton = findViewById(R.id.upload_status);
        progressBar = findViewById(R.id.progessbar);

        // Send button click event
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                // FINAL LIST containing all the url required to sent to server
                List<ImageStatusObject> compressedPath = new ArrayList<>();

                // Iteration to mediaPreviewList
                for(MediaPreview m1: mediaPreviewsList){

                    if(m1.isVideo()){
                        progressBar.setVisibility(View.VISIBLE);
                        // When video trimming is completed this listener is called

                        final String outputVideoFileDir = getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
                        final File outputVideoFileDirUri = new File(outputVideoFileDir);
                        final Uri trimmedVideoURL = Uri.parse(m1.getPath());

                        final String thumbnail = getVideoThumbnail(m1.getPath());

                        // thread handles compression of video
                        Thread thread = new Thread(){
                            @Override
                            public void run() {

                                // Handles rotation of video
                                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                                retriever.setDataSource(SinglePreview.this, trimmedVideoURL);

                                int width = Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                                int height = Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                                int rotation = Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));

                                if(rotation != 0){
                                    width = 0;
                                    height = 0;
                                }

                                boolean isConverted = VideoConverter.getInstance().convertVideo(SinglePreview.this,
                                        trimmedVideoURL,
                                        outputVideoFileDirUri, width, height, 0);

                                if (isConverted) {

                                    // when compression is complete the compressPath list is updated
                                    ImageStatusObject img1 = new ImageStatusObject(thumbnail, VideoConverter.cachedFile.getPath(), true);
                                    compressedPath.add(img1);

                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            progressBar.setVisibility(View.GONE);
                                        }
                                    });
                                }
                                else{
                                    Log.v("hey", "converting");
                                }
                            }
                        };
                        thread.start();

                        // If video is of less than 2 seconds duration it is directly copied
                        // otherwise trim
                    }
                    else{

                        // Creating compressed bitmap
                        Bitmap compressedBitmap = getCompressedBitmap(BitmapFactory.decodeFile(m1.getPath()));

                        // Saving compressed bitmap
                        File file = getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        File output = new File(file, m1.getFileName());
                        try (FileOutputStream out = new FileOutputStream(output)){
                            compressedBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                        }
                        catch (IOException e){
                            e.printStackTrace();
                        }

                        // Creating Thumbnail bitmap
                        Bitmap thumbnail = getThumbnailBitmap(compressedBitmap);

                        // Saving Thumbnail bitmap
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        thumbnail.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                        byte[] byteArray = byteArrayOutputStream.toByteArray();
                        String base64Thumbnail = Base64.encodeToString(byteArray, Base64.DEFAULT);

                        // Creating image status object and adding to list
                        ImageStatusObject img1 = new ImageStatusObject(base64Thumbnail, output.getAbsolutePath(), false);
                        compressedPath.add(img1);

                    }

                }
            }
        });
    }

    private void moveNext() {
        View v = lp.getChildAt(0);
        currentImage = v.getId();
        MediaPreview m1 = getIdOfMedia(currentImage);

        if(m1.isVideo()){
            addVideo(m1);
        }
        else{
            addImage(m1);
        }

    }

    // Returns thumbnail of video in Base64 string
    private String getVideoThumbnail(String uri) {

        Size mSize = new Size(96,96);
        CancellationSignal ca = new CancellationSignal();
        Bitmap bitmapThumbnail = null;

        // API 29 has content resolver method for thumbnail generation
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            try {
                bitmapThumbnail = ThumbnailUtils.createVideoThumbnail(new File(uri), mSize, ca);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else{
            bitmapThumbnail = ThumbnailUtils.createVideoThumbnail(uri, MediaStore.Video.Thumbnails.MICRO_KIND);
        }

        // Thumbnail is converted to base64
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmapThumbnail.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        String base64Thumbnail = Base64.encodeToString(byteArray, Base64.DEFAULT);

        Log.v("thum", base64Thumbnail);
        return base64Thumbnail;
    }


    // Returns the mediaPreview object with a particular ID
    private MediaPreview getIdOfMedia(int currentImage) {

        // checks mediaPreviewList for ID
        for(MediaPreview m1: mediaPreviewsList){
            if(m1.getId() == currentImage){
                return m1;
            }
        }
        return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Triggers when cropped image is sent back to the activity
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();

                // change the image to the cropped image
                if(mediaPreviewsList.size() == 1){
                    MediaPreview m1 = getIdOfMedia(currentImage);
                    m1.setPath(resultUri.getPath());
                    addImage(m1);
                }
                else{
                    ImageView img = lp.findViewById(currentImage);
                    Glide.with(SinglePreview.this).load(resultUri).into(img);
                    MediaPreview m1 = getIdOfMedia(currentImage);
                    m1.setPath(resultUri.getPath());
                    addImage(m1);
                }
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }
    }

    // Set the image view according to the image URI
    public void addImage(MediaPreview m1){

        CropRotation.setVisibility(View.VISIBLE);
        Bitmap bmp = BitmapFactory.decodeFile(m1.getPath());

        ImageStatus.setImageBitmap(bmp);
        VideoStatus.setVisibility(View.GONE);
        ImageStatus.setVisibility(View.VISIBLE);
    }

    // Set the video view according to the video URI
    public void addVideo(@NonNull MediaPreview m1){

        // adding media controls
        MediaController mediaController = new MediaController(this);
        VideoStatus.setVideoPath(m1.getPath());

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        params.setMargins(10, 10, 10, 10);

        CropRotation.setVisibility(View.GONE);


        VideoStatus.requestFocus();

        ImageStatus.setVisibility(View.GONE);
        VideoStatus.setVisibility(View.VISIBLE);

        VideoStatus.setMediaController(mediaController);
        mediaController.setAnchorView(VideoStatus);
        VideoStatus.start();

    }


    // returns compressed/scaled bitmap
    public Bitmap getCompressedBitmap(Bitmap bmp){
        // compression of image happens here
        int nh = (int) ( bmp.getHeight() * (512.0 / bmp.getWidth()) );
        Bitmap scaled = Bitmap.createScaledBitmap(bmp, 512, nh, true);

        return scaled;
    }

    // Generates the thumbnail for the bitmap
    public Bitmap getThumbnailBitmap(Bitmap bm) {

        // Scale by which image should be reduced
        int reduction = 100;

        int width = bm.getWidth();
        int height = bm.getHeight();

        int newWidth = width/reduction;
        int newHeight = height/reduction;

        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);

        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(
                bm, 0, 0, width, height, matrix, false);

        // Blur the scaled down image
        RenderScript rs = RenderScript.create(this);

        final Allocation input = Allocation.createFromBitmap(rs, resizedBitmap); //use this constructor for best performance, because it uses USAGE_SHARED mode which reuses memory
        final Allocation output = Allocation.createTyped(rs, input.getType());
        final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
        script.setRadius(8f);
        script.setInput(input);
        script.forEach(output);
        output.copyTo(resizedBitmap);

        return resizedBitmap;
    }


}